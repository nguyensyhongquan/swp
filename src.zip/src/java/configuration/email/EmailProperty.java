package configuration.email;

public class EmailProperty {
    public static final String HOST_NAME = "smtp.gmail.com";

    public static final int SSL_PORT = 465; // Port for SSL

    public static final int TSL_PORT = 587; // Port for TLS/STARTTLS

    public static final String APP_EMAIL = "quannshde170031@fpt.edu.vn"; // your email

    public static final String APP_PASSWORD = "cona vcql soxc scts"; // your password
}
