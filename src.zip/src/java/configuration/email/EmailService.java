package configuration.email;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.MessagingException;


public class EmailService implements IJavaMail{
    @Override
    public boolean send(String to, String subject, String messageContent) {
        // Get properties object
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", EmailProperty.HOST_NAME); // Tên host của SMTP (ví dụ: smtp.gmail.com)
        props.put("mail.smtp.socketFactory.port", EmailProperty.SSL_PORT); // Cổng SSL (ví dụ: 465)
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.port", EmailProperty.SSL_PORT);

        // get Session
        Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(EmailProperty.APP_EMAIL, EmailProperty.APP_PASSWORD);
            }
        });

        try {
            // Create a MimeMessage object
            MimeMessage message = new MimeMessage(session);
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to)); // Đặt người nhận email
            message.setSubject(subject); // Đặt tiêu đề email
            message.setText(messageContent); // Đặt nội dung email

            // Send message
            Transport.send(message);
            System.out.println("Email sent successfully.");
            return true;
        } catch (MessagingException e) {
            System.err.println("Failed to send email: " + e.getMessage());
            return false;
        }
    }

    public static void main(String[] args) {
        String to = "nguyensyhongquan130703@gmail.com";
        String subject = "Đăng ký nhận thư thành công";
        String message = "Cảm ơn bạn đã đăng ký nhận thư";
        IJavaMail emailService = new EmailService();
        emailService.send(to, subject, message);
    }
}
