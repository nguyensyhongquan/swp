/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Car;


/**
 *
 * @author FPT
 */
public class MaintestCase {
       public static String readTextFile(String filePath) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                content.append(line).append("<br>"); // Thêm <br> để xuống dòng trên HTML
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString();
    }

    public static void main(String[] args) throws IOException, SQLException {
//       
//            // Đường dẫn đến file .docx của bạn
//            String filePath = "C:\\Users\\FPT\\Desktop\\Swp\\web\\post\\databasetamthoi.txt";
//            String content = readTextFile(filePath);
//            System.out.println("Nội dung file:");
//            System.out.println(content); // In ra nội dung để kiểm tra
        boolean check=CarDao.deleteCarById(1);
         System.out.println(check);
    }
}
