/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Car;
import model.Service;

/**
 *
 * @author FPT
 */
public class ServiceDao {
    public static ArrayList<Service> getAllservices()
    {
         ArrayList<Service> services = new ArrayList<>();
        String sql="SELECT * FROM [Service]";
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try (Connection connection = DBConnection.getConnection()) {
            ptm = connection.prepareStatement(sql);
            

            rs = ptm.executeQuery();
            while (rs.next()) {
              Service service = new Service(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("describre")
                );
                services.add(service);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  services;
    }
}
