/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import dto.BookingRequest;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Post;
import model.Service;
import model.User;

/**
 *
 * @author FPT
 */
public class DBConnection {
    public static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
public static String dbURL="jdbc:sqlserver://localhost:1433;databaseName=NewSwp;encrypt=true;trustServerCertificate=true;";
public static String userDB="sa";
public static String passDB="quanchin123";
public static Connection getConnection()
{
    Connection con=null;
    try {
        Class.forName(driverName);
        con=DriverManager.getConnection(dbURL, userDB, passDB);
//        System.out.println("he");
        return con;
    
    } catch (Exception ex) {
        Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE,null,ex);
    }
    return null;
}
    public static void main(String[] args) throws SQLException, JsonProcessingException {
     
       String json = "{ \"carId\": 6000, \"scheduledDate\": \"2024-10-21T10:00\", \"detail\": \"Car needs maintenance\", \"services\": [\"1\", \"2\"] }";

        try {
            ObjectMapper mapper = new ObjectMapper();
            BookingRequest bookingRequest = mapper.readValue(json, BookingRequest.class);
            System.out.println("Car ID: " + bookingRequest.getCarId()+bookingRequest.getDetail()+bookingRequest.getServices().toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
