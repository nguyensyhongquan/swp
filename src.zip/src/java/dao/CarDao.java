/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Car;
import Query.QCar;
import enums.Erole;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.User;

/**
 *
 * @author FPT
 */
public class CarDao {

    public static ArrayList<Car> getCarsByCustomerId(int customerId) {
        ArrayList<Car> cars = new ArrayList<>();
        String sql = QCar.Get_Car_By_Customerid;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try (Connection connection = DBConnection.getConnection()) {
            ptm = connection.prepareStatement(sql);
            ptm.setInt(1, customerId);

            rs = ptm.executeQuery();
            while (rs.next()) {
                Car car = new Car(
                        rs.getInt("id"),
                        rs.getString("licennumber"),
                        rs.getString("company"),
                        rs.getString("name"),
                        rs.getString("color"),
                        rs.getInt("Customerid")
                );
                cars.add(car);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cars;
    }

    public static boolean isLicenseNumberExist(String licensnumber) throws SQLException {
        String sql = QCar.Get_Car_By_License;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try (Connection connection = DBConnection.getConnection()) {
            ptm = connection.prepareStatement(sql);
            ptm.setString(1, licensnumber);

            rs = ptm.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0; // Trả về true nếu đã tồn tại
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean updateCar(Car car) throws SQLException {
        // Kiểm tra xem biển số đã tồn tại với ID khác không
        if ( isLicenseNumberExistForOtherCar(car.getLicenseNumber(),car.getId())) {
            System.out.println("Error: License number already exists!");
            return false;
        }
          PreparedStatement ptm = null;
        ResultSet rs = null;
            String sql = QCar.Update_Car_By_Ida; // Câu lệnh SQL cập nhật xe
            try (Connection connection = DBConnection.getConnection()) {
                 ptm = connection.prepareStatement(sql);
                ptm.setString(1, car.getLicenseNumber());
                ptm.setString(2, car.getCompany());
                ptm.setString(3, car.getName());
                ptm.setString(4, car.getColor());
                ptm.setInt(5, car.getCustomerId());
                ptm.setInt(6, car.getId()); // ID của xe cần cập nhật

                int rowsUpdated = ptm.executeUpdate();
                return rowsUpdated > 0; // Trả về true nếu cập nhật thành công
            } catch (Exception e) {
                e.printStackTrace();
            }
            // Trả về false nếu cập nhật thất bại
        
        return false;}
    

    public static boolean addCar(Car car) throws SQLException {
        if (isLicenseNumberExist(car.getLicenseNumber())) {
            System.out.println("Error: License number already exists!");
            return false;
        }

        String sql = QCar.Insert_New_Car;
        try (Connection connection = DBConnection.getConnection(); PreparedStatement ptm = connection.prepareStatement(sql)) {

            ptm.setString(1, car.getLicenseNumber());
            ptm.setString(2, car.getCompany());
            ptm.setString(3, car.getName());
            ptm.setString(4, car.getColor());
            ptm.setInt(5, car.getCustomerId());

            int rowsInserted = ptm.executeUpdate();
            return rowsInserted > 0; // Trả về true nếu thêm thành công
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false; // Trả về false nếu thêm thất bại
    }
    public static boolean isLicenseNumberExistForOtherCar(String licenseNumber, int carId) throws SQLException {
    String sql = QCar.Check_License_Exist_For_Other_Car;
    try (Connection connection = DBConnection.getConnection();
         PreparedStatement ptm = connection.prepareStatement(sql)) {

        ptm.setString(1, licenseNumber);
        ptm.setInt(2, carId);

        try (ResultSet rs = ptm.executeQuery()) {
            return rs.next() && rs.getInt(1) > 0; // Trả về true nếu đã tồn tại với ID khác
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}
    public static boolean deleteCarById(int carId) {
    String sql = "DELETE FROM Car WHERE id = ?"; // Câu lệnh SQL để xóa xe theo ID
    try (Connection connection = DBConnection.getConnection();
         PreparedStatement ptm = connection.prepareStatement(sql)) {

        ptm.setInt(1, carId); 

        int rowsDeleted = ptm.executeUpdate(); // Thực thi câu lệnh SQL
        return rowsDeleted > 0; // Trả về true nếu xóa thành công
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false; // Trả về false nếu xóa thất bại
}

}
