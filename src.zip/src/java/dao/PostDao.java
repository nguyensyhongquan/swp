/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import model.Post;
import model.User;

/**
 *
 * @author FPT
 */
public class PostDao {
  public static ArrayList<Post> getTopPosts() throws SQLException {
        String sql = "SELECT TOP 24 * FROM [dbo].[post] ORDER BY dateofpost DESC"; // Chỉ lấy 24 bài mới nhất
        ArrayList<Post> list = new ArrayList<>();

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement ptm = connection.prepareStatement(sql)) {

            ResultSet rs = ptm.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String filepath = rs.getString("filepath");
                Date dateofpost = rs.getDate("dateofpost");
                String picture = rs.getString("Picture");

                Post post = new Post(id, title, filepath, dateofpost, picture);
                list.add(post);
            }
        }
        return list;
    }
    public static int getTotalPosts() throws SQLException {
        String sql = "SELECT COUNT(*) as total FROM [dbo].[post]";
        int totalPosts = 0;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement ptm = connection.prepareStatement(sql)) {

            ResultSet rs = ptm.executeQuery();
            if (rs.next()) {
                totalPosts = rs.getInt("total");
            }
        }
        return Math.min(totalPosts, 24); // Giới hạn tổng số bài viết tối đa là 24
    }
    

}
