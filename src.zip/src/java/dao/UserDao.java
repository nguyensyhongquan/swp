/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import Query.QUser;
import enums.Erole;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.User;
import java.sql.*;

/**
 *
 * @author FPT
 */
public class UserDao {
public static User getUser(String email, String password) {
        User user = new User();
        String sql = QUser.GET_USER_BY_EMAIL_AND_PASSWORD;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try (Connection connection = DBConnection.getConnection()) {
            ptm = connection.prepareStatement(sql);
            ptm.setString(1, email);
            ptm.setString(2, password);
            rs = ptm.executeQuery();
            if (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("Name");
                String emailResult = rs.getString("email");
                String passwordResult = rs.getString("password");
                String roleString = rs.getString("role");
                Erole role = Erole.valueOf(roleString);
                String phone = rs.getString("PhoneNumber");
                boolean active = rs.getBoolean("status");
                user=new User(id, name, emailResult, passwordResult, role, phone, active);


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }

     public static boolean checkEmailExists(String email) {
        String sql = QUser.SELECT_USER_BY_EMAIL;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try (Connection connection = DBConnection.getConnection();) {
            ptm = connection.prepareStatement(sql);
            ptm.setString(1, email);
            rs = ptm.executeQuery();

            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static String generateOtp() {

        SecureRandom random = new SecureRandom();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }

    public static boolean resetPassword(String email, String newPassword) {
        String sql = "UPDATE [dbo].[User] SET [password] = ? WHERE [email] = ?";
        PreparedStatement ptm = null;
        try (Connection connection = DBConnection.getConnection()) {
            ptm = connection.prepareStatement(sql);
            ptm.setString(1, newPassword);
            ptm.setString(2, email);

            return ptm.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            // Đảm bảo đóng PreparedStatement nếu nó không null
            if (ptm != null) {
                try {
                    ptm.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static boolean insertUser(User user) {
        String sql = QUser.INSERT_USER;
        PreparedStatement ptm = null;

        try (Connection connection = DBConnection.getConnection()) {
            ptm = connection.prepareStatement(sql);

            ptm.setString(1, user.getName());
            ptm.setString(2, user.getEmail());
            ptm.setString(3, user.getPassword());
            ptm.setString(5, user.getPhone());
            ptm.setString(4,String.valueOf(user.getRole()) );
            
            ptm.setBoolean(6, user.isStatus());

            return ptm.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {

            if (ptm != null) {
                try {
                    ptm.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
