/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import Query.QBooking;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Booking;

/**
 *
 * @author FPT
 */
public class BookingDao {

    public static boolean insertBooking(Booking booking) {
        String sql = QBooking.insert_New_Booking;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try (Connection connection = DBConnection.getConnection()) {
            stmt.setString(1, booking.getCarpicture());
            stmt.setString(2, booking.getCarvideo());
            stmt.setString(3, booking.getStatus());
            stmt.setInt(4, booking.getCarId());
            stmt.setTimestamp(5, java.sql.Timestamp.valueOf(booking.getBookingDate()));
            stmt.setTimestamp(6, java.sql.Timestamp.valueOf(booking.getScheduledDate()));
            stmt.setString(7, booking.getDetail());
            stmt.setBoolean(8, booking.isInGarage());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
           return false;
    }

}
