/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Query;

/**
 *
 * @author FPT
 */
public class QCar {

    public static final String Get_Car_By_Customerid = "SELECT * FROM Car WHERE Customerid = ?";
    public static final String Insert_New_Car = "INSERT INTO Car (licennumber, company, name, color, Customerid) VALUES (?, ?, ?, ?, ?)";
    public static final String Get_Car_By_License = "SELECT COUNT(*) FROM Car WHERE licennumber = ?";
    public static final String Update_Car_By_Ida = "UPDATE Car \n"
            + "SET licennumber = ?, \n"
            + "    company = ?, \n"
            + "    name = ?, \n"
            + "    color = ?, \n"
            + "    Customerid = ? \n"
            + "WHERE id = ?";
    
    public static final String Check_License_Exist_For_Other_Car="SELECT COUNT(*) FROM Car WHERE licennumber = ? AND id != ?";
}
