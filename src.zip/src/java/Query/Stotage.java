package Query;

public class Stotage {
    public static String insert_newItem_Storage = "INSERT INTO [dbo].[Item] " +
            "([name], [detail], [quantity], [price]) " +
            "VALUES (?, ?, ?, ?)";
    public static String select_Item_Storage="SELECT [id]\n" +
            "      ,[name]\n" +
            "      ,[detail]\n" +
            "      ,[quantity]\n" +
            "      ,[price]\n" +
            "  FROM [dbo].[Item]";
    public static String update_Item_Storage = "UPDATE [dbo].[Item] " +
            "SET [name] = ?, [detail] = ?, [quantity] = ?, [price] = ? " +
            "WHERE [id] = ?";
    private static  String GET_ITEM_HISTORY_QUERY =
            "SELECT ih.[id] AS HistoryId, " +
                    "       ih.[ItemId], " +
                    "       i.[name] AS ItemName, " +
                    "       i.[detail] AS ItemDetail, " +
                    "       ih.[ChangeType], " +
                    "       ih.[ChangeQuantity], " +
                    "       ih.[OldQuantity], " +
                    "       ih.[NewQuantity], " +
                    "       ih.[ChangeDate], " +
                    "       ih.[Description] " +
                    "FROM [dbo].[ItemHistory] ih " +
                    "JOIN [dbo].[Item] i ON ih.[ItemId] = i.[id] " +
                    "ORDER BY ih.[ChangeDate] DESC";
    public static String Delete_ITem = "DELETE FROM [dbo].[Item] WHERE [id] = ?";
    public static String getAllItemHistoryQuery =
            "SELECT [id], [ItemId], [ChangeType], [ChangeQuantity], [OldQuantity], [NewQuantity], [ChangeDate], [Description] " +
                    "FROM [dbo].[ItemHistory]";
    public static String insertItemHistoryQuery =
            "INSERT INTO [dbo].[ItemHistory] ([ItemId], [ChangeType], [ChangeQuantity], [OldQuantity], [NewQuantity], [ChangeDate], [Description]) " +
                    "VALUES (?, ?, ?, ?, ?, GETDATE(), ?)";
    public static String updateItemHistoryQuery =
            "UPDATE [dbo].[ItemHistory] " +
                    "SET [ItemId] = ?, [ChangeType] = ?, [ChangeQuantity] = ?, [OldQuantity] = ?, [NewQuantity] = ?, [ChangeDate] = GETDATE(), [Description] = ? " +
                    "WHERE [id] = ?";


}
