package Query;

public class Post {
    public static String getAllPostsQuery =
            "SELECT [id], [title], [filepath], [dateofpost], [Picture] " +
                    "FROM [dbo].[post]";
    public static String insertPostQuery =
            "INSERT INTO [dbo].[post] ([title], [filepath], [dateofpost], [Picture]) " +
                    "VALUES (?, ?, ?, ?)";
    public static String deletePostQuery =
            "DELETE FROM [dbo].[post] " +
                    "WHERE [id] = ?";
    public static String updatePostQuery =
            "UPDATE [dbo].[post] " +
                    "SET [title] = ?, [filepath] = ?, [dateofpost] = ?, [Picture] = ? " +
                    "WHERE [id] = ?";
    public static String getTop4PostsQuery =
            "SELECT TOP 4 [id], [title], [filepath], [dateofpost], [Picture] " +
                    "FROM [dbo].[post] " +
                    "ORDER BY [dateofpost] DESC";

}
