package Query;

public class Staff {
    public static String getStaffDetailsQuery =
            "SELECT u.id AS UserId, " +
                    "       u.Name AS StaffName, " +
                    "       u.email AS StaffEmail, " +
                    "       u.role AS StaffRole, " +
                    "       u.PhoneNumber AS StaffPhoneNumber, " +
                    "       s.id AS StaffDetailId, " +
                    "       s.Address AS StaffAddress, " +
                    "       s.Salary AS StaffSalary, " +
                    "       s.ExperienceLevel AS StaffExperienceLevel " +
                    "FROM [dbo].[User] u " +
                    "JOIN [dbo].[StaffDetail] s ON u.id = s.UserId " +
                    "WHERE u.role <> 'Staff' " +
                    "ORDER BY u.id";

    public static String insertStaffDetailQuery =
            "INSERT INTO [dbo].[StaffDetail] ([UserId], [Address], [Salary], [ExperienceLevel]) " +
                    "VALUES (?, ?, ?, ?)";
    public static String updateStaffDetailQuery =
            "UPDATE [dbo].[StaffDetail] " +
                    "SET [UserId] = ?, [Address] = ?, [Salary] = ?, [ExperienceLevel] = ? " +
                    "WHERE [id] = ?";
}
