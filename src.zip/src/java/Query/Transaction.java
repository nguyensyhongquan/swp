package Query;

public class Transaction {
    public static String getAllTransactionsQuery =
            "SELECT [id], [datestart], [estimateddate], [Bookingid], [dateend], [progress] " +
                    "FROM [dbo].[Transaction]";
    public static String insertTransactionQuery =
            "INSERT INTO [dbo].[Transaction] ([datestart], [estimateddate], [Bookingid], [dateend], [progress]) " +
                    "VALUES (?, ?, ?, ?, ?)";
    public static String updateTransactionQuery =
            "UPDATE [dbo].[Transaction] " +
                    "SET [datestart] = ?, [estimateddate] = ?, [Bookingid] = ?, [dateend] = ?, [progress] = ? " +
                    "WHERE [id] = ?";

}
