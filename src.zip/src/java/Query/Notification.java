package Query;

public class Notification {
    public static String getAllNotificationsQuery =
            "SELECT [id], [time], [detail], [link], [UserId] " +
                    "FROM [dbo].[notification]";
    public static String insertNotificationQuery =
            "INSERT INTO [dbo].[notification] ([time], [detail], [link], [UserId]) " +
                    "VALUES (?, ?, ?, ?)";
    public static String updateNotificationQuery =
            "UPDATE [dbo].[notification] " +
                    "SET [time] = ?, [detail] = ?, [link] = ?, [UserId] = ? " +
                    "WHERE [id] = ?";
}
