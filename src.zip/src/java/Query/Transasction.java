package Query;

public class Transasction {
    public static String getAllTransactionsQuery = "SELECT [id], [datestart], [estimateddate], [Bookingid], [dateend], [progress] FROM [dbo].[Transaction]";
    public static String updateTransactionQuery = "UPDATE [dbo].[Transaction] " +
            "SET [datestart] = ?, [estimateddate] = ?, [Bookingid] = ?, [dateend] = ?, [progress] = ? " +
            "WHERE [id] = ?";

}
