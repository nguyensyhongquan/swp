package Query;

public class Booking {
    public static final String SELECT_ALL_BOOKINGS =
            "SELECT * FROM Booking;";
    public static final String INSERT_NEW_BOOKING =
            "INSERT INTO Booking (carpicture, carvideo, status, Carid, BookingDate, ScheduledDate, Detail, InGarage) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
    public static final String SELECT_BOOKING_BY_CARID =
            "SELECT * FROM Booking WHERE Carid = ?;";
    public static final String SELECT_BOOKING_BY_CUSTOMERID =
            "SELECT * FROM Booking WHERE Carid IN " +
                    "(SELECT id FROM Car WHERE Customerid = ?);";
    public static final String SELECT_ALL_INGARAGE =
            "SELECT * FROM Booking WHERE InGarage = 1;";
    public static final String COUNT_INGARAGE =
            "SELECT COUNT(*) FROM Booking WHERE InGarage = 1;";
    public static final String SELECT_BOOKING_BY_BOOKDATE =
            "SELECT * FROM Booking WHERE BookingDate = ?;";
    public static final String SELECT_BOOKING_BY_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE ScheduledDate = ?;";
    public static final String SELECT_BOOKING_BY_CAR_LICENSE =
            "SELECT * FROM Booking WHERE Carid IN " +
                    "(SELECT id FROM Car WHERE licenseNumber = ?);";
    public static final String UPDATE_BOOKING_STATUS =
            "UPDATE Booking SET status = ? WHERE id = ?;";
    public static final String SELECT_SERVICES_BY_BOOKING_ID =
            "SELECT s.id, s.name, s.describe " +
                    "FROM Service s " +
                    "JOIN ServiceHistory sh ON s.id = sh.serviceid " +
                    "WHERE sh.bookingid = ?;";
    public static final String SELECT_BOOKINGS_PENDING =
            "SELECT * FROM Booking WHERE status = 'Pending';";
    public static final String SELECT_BOOKINGS_CONFIRMED =
            "SELECT * FROM Booking WHERE status = 'Confirmed';";
    public static final String SELECT_BOOKINGS_CHECKEDIN =
            "SELECT * FROM Booking WHERE status = 'Checkedin';";
    public static final String SELECT_BOOKINGS_UNAVAILABLE =
            "SELECT * FROM Booking WHERE status = 'Unavailable';";

    public static final String SELECT_BOOKINGS_CANCELLED =
            "SELECT * FROM Booking WHERE status = 'Cancelled';";
    public static final String SELECT_BOOKINGS_NOSHOW =
            "SELECT * FROM Booking WHERE status = 'NoShow';";

    public static final String SELECT_BOOKINGS_RESCHEDULED =
            "SELECT * FROM Booking WHERE status = 'Rescheduled';";
    public static final String SELECT_BOOKINGS_COMPLETED =
            "SELECT * FROM Booking WHERE status = 'Completed';";
    public static final String SELECT_CONFIRMED_BOOKING_BY_ID =
            "SELECT * FROM Booking WHERE status = 'Confirmed' AND id = ?;";
    public static final String SELECT_CHECKEDIN_BOOKING_BY_ID =
            "SELECT * FROM Booking WHERE status = 'Checkedin' AND id = ?;";
    public static final String SELECT_UNAVAILABLE_BOOKING_BY_ID =
            "SELECT * FROM Booking WHERE status = 'Unavailable' AND id = ?;";
    public static final String SELECT_CANCELLED_BOOKING_BY_ID =
            "SELECT * FROM Booking WHERE status = 'Cancelled' AND id = ?;";
    public static final String SELECT_NOSHOW_BOOKING_BY_ID =
            "SELECT * FROM Booking WHERE status = 'NoShow' AND id = ?;";
    public static final String SELECT_RESCHEDULED_BOOKING_BY_ID =
            "SELECT * FROM Booking WHERE status = 'Rescheduled' AND id = ?;";
    public static final String SELECT_COMPLETED_BOOKING_BY_ID =
            "SELECT * FROM Booking WHERE status = 'Completed' AND id = ?;";
    public static final String SELECT_PENDING_BOOKING_BY_ID_AND_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Pending' AND id = ? AND ScheduledDate = ?;";
    public static final String SELECT_CONFIRMED_BOOKING_BY_ID_AND_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Confirmed' AND id = ? AND ScheduledDate = ?;";
    public static final String SELECT_CHECKEDIN_BOOKING_BY_ID_AND_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Checkedin' AND id = ? AND ScheduledDate = ?;";
    public static final String SELECT_UNAVAILABLE_BOOKING_BY_ID_AND_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Unavailable' AND id = ? AND ScheduledDate = ?;";
    public static final String SELECT_CANCELLED_BOOKING_BY_ID_AND_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Cancelled' AND id = ? AND ScheduledDate = ?;";
    public static final String SELECT_NOSHOW_BOOKING_BY_ID_AND_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'NoShow' AND id = ? AND ScheduledDate = ?;";
    public static final String SELECT_RESCHEDULED_BOOKING_BY_ID_AND_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Rescheduled' AND id = ? AND ScheduledDate = ?;";
    public static final String SELECT_COMPLETED_BOOKING_BY_ID_AND_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Completed' AND id = ? AND ScheduledDate = ?;";
    public static final String SELECT_PENDING_BOOKING_BY_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Pending' AND ScheduledDate = ?;";
    public static final String SELECT_CONFIRMED_BOOKING_BY_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Confirmed' AND ScheduledDate = ?;";
    public static final String SELECT_CHECKEDIN_BOOKING_BY_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Checkedin' AND ScheduledDate = ?;";
    public static final String SELECT_UNAVAILABLE_BOOKING_BY_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Unavailable' AND ScheduledDate = ?;";
    public static final String SELECT_CANCELLED_BOOKING_BY_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Cancelled' AND ScheduledDate = ?;";
    public static final String SELECT_NOSHOW_BOOKING_BY_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'NoShow' AND ScheduledDate = ?;";
    public static final String SELECT_COMPLETED_BOOKING_BY_SCHEDULEDDATE =
            "SELECT * FROM Booking WHERE status = 'Completed' AND ScheduledDate = ?;";
    public static final String SELECT_REPAIR_STATUS_BY_BOOKING_ID =
            "SELECT ro.RepairStatus " +
                    "FROM RepairOrder ro " +
                    "JOIN Booking b ON ro.bookingid = b.id " +
                    "WHERE b.id = ?;";
    public static final String SELECT_UNPAID_ORDERS =
            "SELECT b.id AS billId, b.totalpayment, b.BookingID, bk.status, bk.Carid, " +
                    "bk.BookingDate, bk.ScheduledDate, bk.Detail, bk.InGarage " +
                    "FROM Bill b " +
                    "JOIN Booking bk ON b.BookingID = bk.id " +
                    "WHERE b.paymentstatus = 0;";
    public static final String Get_Bill_Info="SELECT b.id AS billId, b.totalpayment, b.paymentstatus, " +
            "u.Name AS customerName, u.email AS customerEmail, " +
            "c.name AS carName, c.licennumber AS carLicenseNumber, " +
            "ro.StartTime AS startDate, ro.EndTime AS endDate, " +
            "s.id AS serviceId, s.name AS serviceName, s.describe AS serviceDescription " +
            "FROM Bill b " +
            "JOIN Booking bk ON b.BookingID = bk.id " +
            "JOIN RepairOrder ro ON ro.bookingid = bk.id " +
            "JOIN User u ON bk.Customerid = u.id " +
            "JOIN Car c ON bk.Carid = c.id " +
            "JOIN ServiceHistory sh ON sh.bookingid = bk.id " +
            "JOIN Service s ON sh.serviceid = s.id " +
            "WHERE bk.status = 'Completed' AND b.id = ?;";
    private static final String Select_Bill_ByCustomerID=

            "SELECT b.id AS billId, b.totalpayment, b.paymentstatus, " +
                    "u.Name AS customerName, u.email AS customerEmail, " +
                    "c.name AS carName, c.licennumber AS carLicenseNumber, " +
                    "ro.StartTime AS startDate, ro.EndTime AS endDate, " +
                    "s.id AS serviceId, s.name AS serviceName, s.describe AS serviceDescription " +
                    "FROM Bill b " +
                    "JOIN Booking bk ON b.BookingID = bk.id " +
                    "JOIN RepairOrder ro ON ro.bookingid = bk.id " +
                    "JOIN User u ON bk.Customerid = u.id " +
                    "JOIN Car c ON bk.Carid = c.id " +
                    "JOIN ServiceHistory sh ON sh.bookingid = bk.id " +
                    "JOIN Service s ON sh.serviceid = s.id " +
                    "WHERE u.id = ?;";
    private static final String Select_All_Bills=
            "SELECT b.id AS billId, b.totalpayment, b.paymentstatus, " +
                    "u.Name AS customerName, u.email AS customerEmail, " +
                    "c.name AS carName, c.licennumber AS carLicenseNumber, " +
                    "ro.StartTime AS startDate, ro.EndTime AS endDate, " +
                    "s.id AS serviceId, s.name AS serviceName, s.describe AS serviceDescription " +
                    "FROM Bill b " +
                    "JOIN Booking bk ON b.BookingID = bk.id " +
                    "JOIN RepairOrder ro ON ro.bookingid = bk.id " +
                    "JOIN User u ON bk.Customerid = u.id " +
                    "JOIN Car c ON bk.Carid = c.id " +
                    "JOIN ServiceHistory sh ON sh.bookingid = bk.id " +
                    "JOIN Service s ON sh.serviceid = s.id;";
}
