package Query;

public class Bill {
    public static String get_Bill="\n" +
            "SELECT *\n"+

            "  FROM [dbo].[Bill]";
    public static String update_statuspayment_Bill="Update [dbo][Bill] set payment status=? where id=?";
    public static String getBillDetailsQuery =
            "SELECT " +
                    "    b.id AS BillId, " +
                    "    b.dateofexport AS DateOfExport, " +
                    "    b.content AS Content, " +
                    "    b.totalpayment AS TotalPayment, " +
                    "    b.CustomerId AS CustomerId, " +
                    "    bi.id AS BillItemId, " +
                    "    bi.Quantity AS BillItemQuantity, " +
                    "    bi.Price AS BillItemPrice, " +
                    "    i.id AS ItemId, " +
                    "    i.name AS ItemName, " +
                    "    i.detail AS ItemDetail, " +
                    "    i.quantity AS ItemStockQuantity, " +
                    "    i.price AS ItemPrice " +
                    "FROM " +
                    "    [dbo].[Bill] b " +
                    "JOIN " +
                    "    [dbo].[BillItem] bi ON b.id = bi.BillId " +
                    "JOIN " +
                    "    [dbo].[Item] i ON bi.ItemId = i.id " +
                    "ORDER BY " +
                    "    b.id, bi.id;";

}
