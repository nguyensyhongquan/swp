package Query;

public class QUser {
    public static final String GET_USER_BY_EMAIL_AND_PASSWORD =
            "SELECT * FROM [User] WHERE email = ? AND password = ?;";
    public static final String DELETE_USER =
            "DELETE FROM [User] WHERE id = ?;";
    public static final String UPDATE_USER =
            "UPDATE [User] SET Name = ?, email = ?, password = ?, role = ?, PhoneNumber = ?, Status = ? " +
                    "WHERE id = ?;";
    public static final String INSERT_USER =
            "INSERT INTO [User] (Name, email, password, role, PhoneNumber, Status) " +
                    "VALUES (?, ?, ?, ?, ?, ?);";
    public static final String UPDATE_USER_STATUS =
            "UPDATE [User] SET Status = ? WHERE id = ?;";
    public static final String GET_ACTIVE_USERS =
            "SELECT * FROM [User] WHERE Status = 1;";
    public static final String GET_BLOCK_USERS =
            "SELECT * FROM [User] WHERE Status = 0;";
    public static final String GET_ALL_USERS =
            "SELECT * FROM [User];";
    public static final String SELECT_USER_BY_EMAIL =
            "SELECT * FROM [User] WHERE email = ?;";
    public static final String SELECT_USER_BY_PHONE =
            "SELECT * FROM [User] WHERE PhoneNumber = ?;";
    public static final String SELECT_USER_BY_ID =
            "SELECT * FROM [User] WHERE id = ?;";
    public static final String UPDATE_USER_TO_INACTIVE =
            "UPDATE [User] SET Status = 0 WHERE id = ?;";
    public static final String UPDATE_USER_TO_ACTIVE =
            "UPDATE [User] SET Status = 1 WHERE id = ?;";
    public static final String UPDATE_USER_PASSWORD_BY_EMAIL =
            "UPDATE [User] SET password = ? WHERE email = ?;";

}
