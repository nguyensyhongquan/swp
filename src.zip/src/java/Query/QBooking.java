/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Query;

/**
 *
 * @author FPT
 */
public class QBooking {
    public static final String insert_New_Booking="INSERT INTO Booking (carpicture, carvideo, status, Carid, BookingDate, ScheduledDate, Detail, InGarage) " + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
}
