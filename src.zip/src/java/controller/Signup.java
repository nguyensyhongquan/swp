/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.UserDao;
import enums.Erole;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.User;
import org.json.simple.JSONObject;

/**
 *
 * @author FPT
 */
@WebServlet(name = "Signup", urlPatterns = {"/signup"})
public class Signup extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String email = request.getParameter("email");
        String phoneNumber = request.getParameter("phoneNumber");
        String password = request.getParameter("password");
        String fullName = request.getParameter("fullName");

        JSONObject jsonResponse = new JSONObject();
        User user = new User(0,fullName,email,password,Erole.Customer,phoneNumber,true);
        boolean checksignup = UserDao.insertUser(user);
        if (checksignup) {
            jsonResponse.put("status","success");
            jsonResponse.put("message","Sign-up successfully");
        }
        else{
            jsonResponse.put("status","failed");
            jsonResponse.put("message","Sign-up failed");
        }
       
        // Ghi phản hồi JSON duy nhất
        response.getWriter().write(jsonResponse.toString());
    }

}
