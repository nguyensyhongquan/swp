/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.CarDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Car;
import model.User;
import org.json.simple.JSONObject;

/**
 *
 * @author FPT
 */
@WebServlet(name = "CarServlet", urlPatterns = {"/carservlet"})
public class CarServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CarServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet CarServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("currentUser");
        String action = request.getParameter("action");
        if ("view".equals(action)) {
            int customerid = user.getId();
            ArrayList<Car> cars = CarDao.getCarsByCustomerId(customerid);
            request.getSession().setAttribute("listCar", cars);
            request.getRequestDispatcher("CarList.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String licennumber = request.getParameter("license_number");
        String company = request.getParameter("company");
        String name = request.getParameter("name");
        String color = request.getParameter("color");
        User user = (User) request.getSession().getAttribute("currentUser");
        int customerId = user.getId(); // Nếu có input customer_id  
        Car car = new Car(0, licennumber, company, name, color, customerId);
        JSONObject jsonResponse = new JSONObject();
        switch (action) {

            case "add": {
                try {
                    boolean success = CarDao.addCar(car);
                    if (success) {
                        jsonResponse.put("status", "success");
                        jsonResponse.put("message", "Car added successfully.");
                    } else {
                        jsonResponse.put("status", "error");
                        jsonResponse.put("message", "Failed to add car. License number might already exist.");
                    }

                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(jsonResponse.toString());

                } catch (SQLException ex) {

                    jsonResponse.put("status", "error");
                    jsonResponse.put("message", "Failed to add car. License number might already exist.");
                    Logger.getLogger(CarServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            break;
            case "edit":
                int carId = Integer.parseInt(request.getParameter("id"));
                Car updatedCar = new Car(carId, licennumber, company, name, color, customerId);
                 {
                    try {
                        boolean isupdatesc = CarDao.updateCar(updatedCar);
                        if (isupdatesc) {
                            jsonResponse.put("status", "success");
                            jsonResponse.put("message", "Car Update successfully.");
                        } else {
                            jsonResponse.put("status", "error");
                            jsonResponse.put("message", "Failed to Update car. License number might already exist.");
                        }
                        response.setContentType("application/json");
                        response.setCharacterEncoding("UTF-8");
                        response.getWriter().write(jsonResponse.toString());

                    } catch (SQLException ex) {
                        Logger.getLogger(CarServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                break;
            case "delete":
                int carIdd = Integer.parseInt(request.getParameter("id"));
                
                boolean isdeletesc = CarDao.deleteCarById(carIdd);
                if (isdeletesc) {
                    jsonResponse.put("status", "success");
                    jsonResponse.put("message", "Car delete successfully.");
                }
                
                else{
                            jsonResponse.put("status", "error");
                            jsonResponse.put("message", "Failed to Delete car!");
                }
                         response.setContentType("application/json");
                        response.setCharacterEncoding("UTF-8");
                        response.getWriter().write(jsonResponse.toString());
                break;

        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
