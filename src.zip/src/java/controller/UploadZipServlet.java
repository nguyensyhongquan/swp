package controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet(name = "Upload", urlPatterns = {"/upload"})
@MultipartConfig
public class UploadZipServlet extends HttpServlet {

    // Thư mục lưu trữ file
    private static final String UPLOAD_DIRECTORY = "C:\\Users\\FPT\\Desktop\\Swp\\web\\docfile";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Kiểm tra và tạo thư mục nếu chưa tồn tại
        File uploadDir = new File(UPLOAD_DIRECTORY);
        if (!uploadDir.exists()) uploadDir.mkdirs();  // Dùng mkdirs() để tạo thư mục cha nếu cần

        // Nhận file ZIP từ form
        Part filePart = request.getPart("zipFile");
        try (InputStream inputStream = filePart.getInputStream();
             ZipInputStream zipInputStream = new ZipInputStream(inputStream)) {

            ZipEntry entry;
            while ((entry = zipInputStream.getNextEntry()) != null) {
                // Xử lý đường dẫn đúng cách
                String filePath = new File(UPLOAD_DIRECTORY, entry.getName()).getCanonicalPath();

                // Kiểm tra nếu filePath không nằm trong uploadDir để tránh lỗi bảo mật
                if (!filePath.startsWith(uploadDir.getCanonicalPath())) {
                    throw new IOException("Invalid entry: " + entry.getName());
                }

                // Nếu là thư mục, tạo thư mục
                if (entry.isDirectory()) {
                    new File(filePath).mkdirs();
                } else {
                    // Nếu là file, giải nén ra
                    File parentDir = new File(filePath).getParentFile();
                    if (!parentDir.exists()) parentDir.mkdirs();  // Đảm bảo thư mục cha tồn tại

                    try (FileOutputStream fos = new FileOutputStream(filePath)) {
                        byte[] buffer = new byte[1024];
                        int len;
                        while ((len = zipInputStream.read(buffer)) > 0) {
                            fos.write(buffer, 0, len);
                        }
                    }
                }
                zipInputStream.closeEntry();
            }
        }

        // Phản hồi thành công
        response.getWriter().println("Upload và giải nén thành công!");
    }
}
