/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package controller;

import dao.UserDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONObject;

/**
 *
 * @author FPT
 */
@WebServlet(name="ResetPassword", urlPatterns={"/reset-password"})
public class ResetPasswordServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Thiết lập kiểu nội dung phản hồi là JSON
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // Lấy dữ liệu từ request gửi lên
        String email = request.getParameter("email");
        System.out.println("email nhận được là" + email);
        
        String newPassword = request.getParameter("password");
        System.out.println("password nhan ddc la "+newPassword);

        // Tạo đối tượng JSON để phản hồi
        JSONObject jsonResponse = new JSONObject();



        // Sử dụng phương thức resetPassword để cập nhật mật khẩu
        boolean updateSuccess = UserDao.resetPassword(email, newPassword);

        if (updateSuccess) {
            // Nếu cập nhật mật khẩu thành công
            jsonResponse.put("status", "success");
            jsonResponse.put("message", "Password has been successfully reset.");
        } else {
            // Nếu cập nhật mật khẩu không thành công
            jsonResponse.put("email", email);
            jsonResponse.put("password", newPassword);
            jsonResponse.put("status", "error");
            jsonResponse.put("message", "Failed to reset password. Please try again.");
        }

        // Gửi phản hồi JSON về client
        response.getWriter().write(jsonResponse.toString());
    }
}