/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package controller;

import dao.UserDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.simple.JSONObject;

/**
 *
 * @author FPT
 */
@WebServlet(name="Checkemailforsignup", urlPatterns={"/checkemailsignup"})
public class Checkemailforsignup extends HttpServlet {
   
        @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
  
        String email = request.getParameter("email");
            
        
        HttpSession session = request.getSession();
        System.out.println(email);
  
        boolean emailExists = UserDao.checkEmailExists(email);


        JSONObject jsonResponse = new JSONObject();

        if (!emailExists) {
         
            String otp = UserDao.generateOtp();
            session.setAttribute("otp", otp); 
            session.setAttribute("emailcf", email); 
            session.setAttribute("showOtpForm", true); 


           EmailService emailService = new EmailService();
            emailService.send(email, "The OTP (don't share with anyone)", "Your OTP is: " + otp);

     
            jsonResponse.put("otp", otp);
            jsonResponse.put("status", "success");
            jsonResponse.put("message", "OTP sent to your email.");
        } else {
     
         
            jsonResponse.put("status", "error");
            jsonResponse.put("message", "Email does not exist.");
        }

    
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

 
        response.getWriter().write(jsonResponse.toString());
    }
}
