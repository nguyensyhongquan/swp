package controller;

import dao.UserDao;  // Import lớp DAO chứa phương thức kiểm tra email
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.simple.JSONObject;

@WebServlet(name = "Checkemail", urlPatterns = {"/checkemail"})
public class Checkemail extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Lấy email từ request
        String email = request.getParameter("email");
            
        
        HttpSession session = request.getSession();
        System.out.println(email);
        // Kiểm tra email có tồn tại trong cơ sở dữ liệu hay không
        boolean emailExists = UserDao.checkEmailExists(email);

        // Tạo đối tượng JSON để phản hồi
        JSONObject jsonResponse = new JSONObject();

        if (emailExists) {
            // Email tồn tại, gửi OTP và phản hồi JSON
            String otp = UserDao.generateOtp();
            session.setAttribute("otp", otp); // Lưu OTP vào session
            session.setAttribute("emailcf", email); // Đặt thuộc tính emailcf
            session.setAttribute("showOtpForm", true); // Hiển thị form OTP

            // Gửi OTP qua email
           EmailService emailService = new EmailService();
            emailService.send(email, "The OTP (don't share with anyone)", "Your OTP is: " + otp);

            // Thiết lập phản hồi JSONư\
            jsonResponse.put("otp", otp);
            jsonResponse.put("status", "success");
            jsonResponse.put("message", "OTP sent to your email.");
        } else {
            // Email không tồn tại, phản hồi JSON với trạng thái lỗi
         
            jsonResponse.put("status", "error");
            jsonResponse.put("message", "Email does not exist.");
        }

        // Thiết lập kiểu nội dung và mã hóa phản hồi
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // Ghi phản hồi JSON duy nhất
        response.getWriter().write(jsonResponse.toString());
    }
}