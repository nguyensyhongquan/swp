/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package controller;

import Query.Booking;
import com.fasterxml.jackson.databind.ObjectMapper;
import dao.CarDao;
import dao.ServiceDao;
import dto.BookingRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Car;
import model.Service;
import model.User;

/**
 *
 * @author FPT
 */
@WebServlet(name="BookingServlet", urlPatterns={"/bookingservlet"})
public class BookingServlet extends HttpServlet {
   
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet BookingServlet</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet BookingServlet at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
          User user = (User) request.getSession().getAttribute("currentUser");
     
       String action = request.getParameter("action");
        if ("view".equals(action)) {
            int customerid = user.getId();
            System.out.println("afaefgfgfgfgfgfgfgfgfgfgfgfgfgfgfgfg"+customerid);
            ArrayList<Car> cars = CarDao.getCarsByCustomerId(customerid);
            for(Car c:cars)
            {
                System.out.println("hiiiiiiiiiiii"+c.toString());
            }
            ArrayList<Service> services=ServiceDao.getAllservices();
                    
            request.getSession().setAttribute("listCar", cars);
              request.getSession().setAttribute("listService", services);
            request.getRequestDispatcher("Booking.jsp").forward(request, response);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    
    // Lấy user hiện tại từ session
    User user = (User) request.getSession().getAttribute("currentUser");
    String action = request.getParameter("action");

    switch (action) {
        case "insert":
            try {
                // Đọc dữ liệu JSON từ request body
                StringBuilder jsonBuffer = new StringBuilder();
                String line;
                try (BufferedReader reader = request.getReader()) {
                    while ((line = reader.readLine()) != null) {
                        jsonBuffer.append(line);
                    }
                }

          
                ObjectMapper mapper = new ObjectMapper();
                BookingRequest bookingRequest = mapper.readValue(jsonBuffer.toString(), BookingRequest.class);

                // Lấy các thông tin từ đối tượng bookingRequest
                int carId = bookingRequest.getCarId();
                String detail = bookingRequest.getDetail();
                String scheduledDateStr = bookingRequest.getScheduledDate();
                String[] services = bookingRequest.getServices();

                // Chuyển đổi chuỗi thành LocalDateTime
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
                LocalDateTime scheduledDate = LocalDateTime.parse(scheduledDateStr, formatter);

                // Thêm mới booking vào database (giả sử BookingDao đã được triển khai)
                Booking booking = new Booking();
                booking.setCarId(carId);
                booking.setDetail(detail);
                booking.setScheduledDate(scheduledDate);
                booking.setBookingDate(LocalDateTime.now());
                booking.setStatus("Pending");

                int bookingId = BookingDao.insertBooking(booking);

                // Lưu service history cho các dịch vụ đã chọn
                for (String serviceId : services) {
                    ServiceHistory history = new ServiceHistory();
                    history.setBookingId(bookingId);
                    history.setServiceId(Integer.parseInt(serviceId));
                    ServiceHistoryDao.insertServiceHistory(history);
                }

                // Trả về JSON response thành công
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write("{\"success\":true}");

            } catch (Exception e) {
                e.printStackTrace();
                response.getWriter().write("{\"success\":false, \"message\":\"" + e.getMessage() + "\"}");
            }
            break;

        default:
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
    }
}

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
