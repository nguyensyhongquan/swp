/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author FPT
 */
public class Car {
      private int id;
    private String licenseNumber;  // Đổi tên cho nhất quán với DB
    private String company;
    private String name;  // 'model' đổi thành 'name' để khớp với DB
    private String color;
    private int customerId;  // Đảm bảo khóa ngoại CustomerId

    // Constructor không tham số
    public Car() {}

    // Constructor đầy đủ
    public Car(int id, String licenseNumber, String company, String name, String color, int customerId) {
        this.id = id;
        this.licenseNumber = licenseNumber;
        this.company = company;
        this.name = name;
        this.color = color;
        this.customerId = customerId;
    }

    // Getter và Setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    @Override
    public String toString() {
        return "Car{" + "id=" + id + ", licenseNumber=" + licenseNumber + ", company=" + company + ", name=" + name + ", color=" + color + ", customerId=" + customerId + '}';
    }
    
}
