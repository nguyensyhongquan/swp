/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author FPT
 */
public class Post {
    private int id;
    private String title;
    private String filepath;
    private Date date;
    private String picture;

    public Post() {
    }

    public Post(int id, String title, String filepath, Date date, String picture) {
        this.id = id;
        this.title = title;
        this.filepath = filepath;
        this.date = date;
        this.picture = picture;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    @Override
    public String toString() {
        return "Post{" + "id=" + id + ", title=" + title + ", filepath=" + filepath + ", date=" + date + ", picture=" + picture + '}';
    }
    

    
}
