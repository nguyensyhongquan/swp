/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author FPT
 */
import java.time.LocalDateTime;

public class Booking {
    private int id;
    private String carpicture;
    private String carvideo;
    private String status;
    private int carId;
    private LocalDateTime bookingDate;
    private LocalDateTime scheduledDate;
    private String detail;
    private boolean inGarage;

    // Getters và Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCarpicture() {
        return carpicture;
    }

    public void setCarpicture(String carpicture) {
        this.carpicture = carpicture;
    }

    public String getCarvideo() {
        return carvideo;
    }

    public void setCarvideo(String carvideo) {
        this.carvideo = carvideo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public LocalDateTime getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDateTime bookingDate) {
        this.bookingDate = bookingDate;
    }

    public LocalDateTime getScheduledDate() {
        return scheduledDate;
    }

    public void setScheduledDate(LocalDateTime scheduledDate) {
        this.scheduledDate = scheduledDate;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public boolean isInGarage() {
        return inGarage;
    }

    public void setInGarage(boolean inGarage) {
        this.inGarage = inGarage;
    }
}
