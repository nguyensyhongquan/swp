package enums;

public enum EBookingStatus {

    Pending,Confirmed,Checkedin,Unavailable,Cancelled,NoShow,Rescheduled,Completed
}
