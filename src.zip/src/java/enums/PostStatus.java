package enums;

public enum PostStatus {
    DRAFT,         // Bản nháp - Không hiển thị công khai
    PUBLISHED,     // Đã xuất bản - Hiển thị công khai
    ARCHIVED,      // Lưu trữ - Không còn hiển thị công khai
    PINNED,        // Ghim - Hiển thị ưu tiên
    SCHEDULED      // Lên lịch xuất bản
}
