package enums;

public enum RepairStatus {
    Receiving(1) , Start_Repair(2),Final_Check(3),Washing(4),Payment_Required(5),Complete(6);
    private final int code;
    RepairStatus(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
