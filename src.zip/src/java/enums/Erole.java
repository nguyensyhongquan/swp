package enums;

public enum Erole {
    Customer,Manager,Staff
}
