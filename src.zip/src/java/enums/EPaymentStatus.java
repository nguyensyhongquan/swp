package enums;

public enum EPaymentStatus {
    Pending,Paid
}
